package collection;

import java.util.HashSet;

public class Ex06 {
	public static void main(String[] args) {
		//Set : 순번이 없고, 값의 중복을 허용하지 않는다.
		/// 셋(집합)은 abc초콜릿 처럼 순서가 없고, 중복이 불가하다. 
		/// 리스트는 페레로로쉐
		
		HashSet<Integer> set = new HashSet<>();
		/// 프리미티는 객체가 아니다.
		// Generic Type에는 primitive 타입을 지정할 수 없다.
		// 대신 wrapper class를 이용하여 지정할 수 있다.
		
		set.add(10);
		set.add(20);
		set.add(30);
		set.add(20);
		
		System.out.println(set);
		
		// 순번이 없어서, 특정 값을 지정해서 불러올 수 없다.
		// System.out.println(set.get(0));
		for(Integer num : set) {
			System.out.println(num);
		}
		System.out.println();
		
		System.out.println("set.size() : "+ set.size());
		
		
		
		
	}

}

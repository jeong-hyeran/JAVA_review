package day21;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);

		Handler handler = new Handler();
		handler.load(); //특정 파일이름의 데이터를 리스트에 불러오기
		
		List<PhoneBookInfo> list = null;
		List<PhoneBookInfo>list2 = null;
		String name,pnum,keyword;
		int menu =-1,age,row;
		
		while(menu != 0) {
			System.out.println("1) 전체목록");
			System.out.println("2) 추가하기");
			System.out.println("3) 저장하기");
			System.out.println("4) 검색하기");
			System.out.println("5) 삭제하기");
			System.out.println("0) 종료하기");
			System.out.print("선택>>>");
			menu = Integer.parseInt(sc.nextLine());
			
			switch(menu) {
			case 1:
				System.out.println("[전체 목록]");
				list = handler.select();
				list.forEach(ob -> System.out.println(ob));
				break;
				
			case 2: //추가
				System.out.println("저장 데이터를 입력하세요");
				System.out.print("이름 :");	
				name = sc.nextLine();
				System.out.print("나이 :");	
				age = Integer.parseInt(sc.nextLine());
				System.out.println("폰번호 [(-) 포함해서 작성] :");	
				pnum = sc.nextLine();

				row = handler.insert(new PhoneBookInfo(name,age,pnum));
				System.out.println(row != 0?"추가성공":"추가 실패");
			
				break;
				
			case 3: //저장
				handler.save();
				break;
				
			case 4: //검색
				
				System.out.print("검색할 이름을 입력 하세요 : ");
				keyword = sc.nextLine();
				list2 = handler.search(keyword);
				System.out.println(list2);
				break;
				
			} // End of switch
		}// End of while
		System.out.println("프로그램 종료");
		
		sc.close();
	}
	

}

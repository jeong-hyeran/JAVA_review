//package programmers;
//
//class Solution {
//    public int solution(int n) {
//        int answer = 0;
//        
//        if( n% 7 == 0)
//            answer = n / 7;
//        else
//            answer = n / 7 + 1;
//        return answer;
//    }
//}
//
//
//
//public class Ex01 {
//	public static void main(String[] args) {
//		
//		Solution sol = new Solution();
//		sol.solution(15);
//		System.out.println(sol.solution(15));
//		
//	}
//
//}
